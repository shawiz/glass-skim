"""
Stream Control Transmission Protocol (SS7 and TCP/IP protocol stacks)
"""
