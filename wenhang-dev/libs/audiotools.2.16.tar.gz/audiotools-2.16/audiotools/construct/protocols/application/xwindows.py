"""
X-Windows (TCP/IP protocol stack)
"""
