"""
Microsoft Windows NetBIOS (TCP/IP protocol stack)
"""
