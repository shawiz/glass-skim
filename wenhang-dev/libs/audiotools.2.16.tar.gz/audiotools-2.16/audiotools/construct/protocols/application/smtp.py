"""
the Simple Network Management Protocol (SNMP)
"""